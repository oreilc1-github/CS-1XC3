// Conor O'Reilly Juarez
// 400237588

/**
* @file student.c
* @author CS 1XC3
* @date 4/6/2022
* @brief functions related to the Student type
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
* adds a grade to a student
* @param student a student represented by the Student type
* @param grade a grade represented by a double
* @return none
*/
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  /**
  * if new grade is first and only grade so far given, allocate memory in the student for one grade but keep that value empty ("reserving an empty slot for the grade")
  */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  /**
  * otherwise, reallocate memory to fit one more grade
  */
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  /**
  *newest grade given gets added into grades array under the student ("grade takes the empty slot")
  */
  student->grades[student->num_grades - 1] = grade;
}

/**
* calculates the students average grade
* @param student a student represented by the Student type
* @return student's average grade represented as a double
*/
double average(Student* student)
{
  /**
  * if student has no grades, average grade returns as 0
  */
  if (student->num_grades == 0) return 0;
  /**
  * otherwise, count up all the grades, and divide by the number of grades to get an average grade
  */
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
* prints a student's information
* @param student a student represented by the Student type
*/
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
* creates a new student with randomized information and allocates memory for them
* @param grades the number of grades the student has
* @return a new student represented by type Student
*/
Student* generate_random_student(int grades)
{
  /**
  * all available first names
  */
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  /**
  * all available last names
  */
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  /**
  * allocate memory for one student but keep that value empty ("reserving an entry in the system for a new student")
  */
  Student *new_student = calloc(1, sizeof(Student));

  /**
  * randomly selects a first and last name
  */
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  /**
  * randomly generates a student ID
  */
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  /**
  * randomly generates grades for how many grades the student has (function input)
  */
  for (int i = 0; i < grades; i++) 
  {
    /**
    * grades are at mininum 25, at maximum 100
    */
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  /**
  * returns the new student
  */
  return new_student;
}