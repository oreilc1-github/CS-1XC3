// Conor O'Reilly Juarez
// 400237588

/**
* @file course.c
* @author CS 1XC3
* @date 4/6/2022
* @brief functions related to the Course type
*/

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
* adds a student into a course
* @param course a pointer to the course represented by type Course the student is being enrolled in
* @param student a ponter to the student represented by type Student being enrolled
* @return none
*/
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  /** 
  * if new student is first and only student so far enrolled, allocate memory in the course for one student but keep that value empty ("reserving an empty seat for the student")
  */
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  /**
  * otherwise, reallocate memory to fit one more student
  */
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  /**
  * newest student enrolled gets added into students array under course ("student takes the empty seat")
  */
  course->students[course->total_students - 1] = *student;
}

/**
* prints information about a course
* @param course the selected course represented by type Course
* @return none
*/
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
* returns the student with the highest grade in the course
* @param course course represented by type Course the top student is being searched for in
* @return top student represented by type Student in the course
*/
Student* top_student(Course* course)
{
  /** 
  * if no students are in a course, can't have a top student in that course!
  */
  if (course->total_students == 0) return NULL;

  /**
  * initializes comparison variables
  */
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  /**
  * goes through the list of students in a course, if a higher grade is found than the old maximum, the maximum and top student are updated
  */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  /**
  * returns the top student in the course
  */
  return student;
}

/**
* returns an array of students who are passing the course
* @param course course represented by type Course
* @param total_passing pointer to type int of total number of students passing
* @return an array of the passing students in a course
*/
Student *passing(Course* course, int *total_passing)
{
  /**
  * originally, the list of students passing is empty (NULL)
  */
  int count = 0;
  Student *passing = NULL;
  
  /**
  * counts the number of passing grades in the class
  */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  /**
  * allocates memory for an empty array of passing students, the length being the number of passing grades
  */
  passing = calloc(count, sizeof(Student));

  /**
  * records the students who are passing the course and adds them to the passing array
  */
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }
  
  /**
  * the total amount of passing students is equal to the count used in these functions
  */
  *total_passing = count;

  /**
  * returns the array of passing students
  */
  return passing;
}