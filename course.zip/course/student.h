// Conor O'Reilly Juarez
// 400237588

/**
* @file student.h
* @author CS 1XC3
* @date 4/6/2022
* @brief library of Student type structure and functions initalizations
*/

/**
* defines a structure for a new type of value, Student, with a variety of parameters
*/
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's ID number */
  double *grades; /**< the student's grades */
  int num_grades; /**< the student's number of grades */
} Student;

/**
* function initialization
*/
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
