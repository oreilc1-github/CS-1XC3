// Conor O'Reilly Juarez
// 400237588

/**
* @file course.h
* @author CS 1XC3
* @date 4/6/2022
* @brief library of Course type structure and functions initalizations
*/

#include "student.h"
#include <stdbool.h>

/** 
* defines a structure for a new type of value, Course, with a variety of parameters
*/
typedef struct _course 
{
  char name[100]; /**< the course's name */
  char code[10]; /**< the course's code */
  Student *students; /**< the course's students */
  int total_students; /**< the course's number of students */
} Course;

/**
* function initialization
*/
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


